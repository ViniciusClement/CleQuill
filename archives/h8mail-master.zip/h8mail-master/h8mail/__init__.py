# -*- coding: utf-8 -*-

"""Top-level package for h8mail."""

from h8mail.utils.version import __version__

__author__ = """khast3x"""
__email__ = "k@kast3x.club"
