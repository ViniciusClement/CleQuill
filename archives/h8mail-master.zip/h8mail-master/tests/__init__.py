# -*- coding: utf-8 -*-

"""Unit test package for h8mail."""
