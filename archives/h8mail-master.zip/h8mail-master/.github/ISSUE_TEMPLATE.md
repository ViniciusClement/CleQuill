*Issues not respecting the issue template will be closed without being read, thank you.*

### Checkbox

- [ ] I have thoroughly checked the answer is not in the [wiki](https://github.com/khast3x/h8mail/wiki).

### Env

* h8mail version:
* Python version:
* Operating System:

### Description

Describe what you were trying to get done.
Tell us what happened, what went wrong, and what you expected to happen.

### What I Did

```
Paste the command(s) you ran and the output.
If there was a crash, please include the traceback here.
```
