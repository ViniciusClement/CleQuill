package core

const (
	Name    = "aquatone"
	Version = "1.7.0"
	Author  = "Michael Henriksen"
	Website = "https://github.com/michenriksen/aquatone"
)
