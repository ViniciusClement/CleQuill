package core

const (
	SessionStart  = "session:start"
	SessionEnd    = "session:end"
	Host          = "host"
	URL           = "url"
	URLResponsive = "url:responsive"
	TCPPort       = "port:tcp"
)
