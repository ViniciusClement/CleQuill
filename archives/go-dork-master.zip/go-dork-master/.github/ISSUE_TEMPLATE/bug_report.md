---
name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: bug
assignees: dwisiswant0

---

### Issue and Steps to Reproduce
<!-- Describe your issue and tell us how to reproduce it (include any useful information). -->

### Versions

### Screenshots

#### Expected

#### Actual

### Specifications

  - Version:
  - Platform:
  - Subsystem:
