package main

const (
	Version = "v1.0.1"
	banner  = `
                   __         __  
  ___ ____  ______/ /__  ____/ /__
 / _ '/ _ \/__/ _  / _ \/ __/  '_/
 \_, /\___/   \_,_/\___/_/ /_/\_\ 
/___/
       ` + Version + ` - @dwisiswant0
`
)
