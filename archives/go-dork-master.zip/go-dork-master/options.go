package main

type options struct {
	Query, Engine, Proxy string
	Page                 int
	Headers              []string
}
