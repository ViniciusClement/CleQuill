# Define constants
CONST_SEARCH_ENGINES = "search_engines"
CONST_URL = "url"
CONST_NAME = "name"
CONST_METADATA = "metadata"
CONST_STATUS_CODE = "status_code"
